import pickle
import RegUtils

corepCorpus = RegUtils.readPickle( "D:\A372517\EXPERIMENT\RegTech\models\corep-corpus.pkl")
corepCorpus.to_csv('corep-corpus.csv',encoding='utf-8', index=False,sep=";")

corepRecords = RegUtils.readPickle( "D:\A372517\EXPERIMENT\RegTech\models\corep-metrics.pkl")
corepRecords.to_csv('corep-records.csv',encoding='utf-8', index=False,sep=";")

corepCorpus = RegUtils.readPickle( "D:\A372517\EXPERIMENT\RegTech\models\\finrep-corpus.pkl")
corepCorpus.to_csv('finrep-corpus.csv',encoding='utf-8', index=False,sep=";")

corepRecords = RegUtils.readPickle( "D:\A372517\EXPERIMENT\RegTech\models\\finrep-metrics.pkl")
corepRecords.to_csv('finrep-records.csv',encoding='utf-8', index=False,sep=";")

corepRecords = RegUtils.readPickle( "D:\A372517\EXPERIMENT\RegTech\models\\eba-metrics.pkl")
corepRecords.to_csv('eba-metrics.csv',encoding='utf-8', index=False,sep=";")

corepRecords = RegUtils.readPickle( "D:\A372517\EXPERIMENT\RegTech\models\\eba-corpus.pkl")
corepRecords.to_csv('eba-corpus.csv',encoding='utf-8', index=False,sep=";")

print ("Done")
