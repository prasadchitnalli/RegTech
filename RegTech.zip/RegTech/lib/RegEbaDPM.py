import RegUtils
import RegParser
import RegModels
import pandas as pd
import re
import numpy as np
from io import StringIO
import logging
logging.basicConfig(format='[%(asctime)s] %(message)s', datefmt='%m/%d/%Y %I:%M:%S %p')

## features
from sklearn.feature_extraction.text import CountVectorizer,TfidfTransformer,TfidfVectorizer
from sklearn.feature_selection import chi2
from sklearn.model_selection import train_test_split, cross_val_score

def MultinomialNaiveBayes(x, y, modelLabel, countVectorNameLabel):   
    (x,y, MultinomialNB_model, countVect) = RegModels.naiveBayesModel(x, y)
    RegModels.saveModel(MultinomialNB_model, modelLabel, cfg)
    RegModels.saveModel(countVect, countVectorNameLabel, cfg)

def LinearSVC(x, y,modelLabel, countVectorNameLabel):
    (linearSVCModel, countVect) = RegModels.linearSVCModel(x, y)
    RegModels.saveModel(linearSVCModel, modelLabel, cfg)
    RegModels.saveModel(countVect, countVectorNameLabel, cfg)

def buildEBATableModels(EBACorpus,cfg):
    #### Build multinomial Naive Bayes Model ####   
    MultinomialNaiveBayes(EBACorpus['CORPUS'], EBACorpus['TABLE'], "multinomialNB", "multinomialNBCV")
    #### Build Linear SVC Model ####   
    LinearSVC(EBACorpus['CORPUS'], EBACorpus['TABLE'], "linearSVC", "linearSVCCV" )
    

def buildEBAMetricModel(EBARecords, cfg):
    #### Build multinomial Naive Bayes Model ####   
    MultinomialNaiveBayes(EBARecords['ROW'], EBARecords['TABLE'], "multinomialNBMerics", "multinomialNBCVMetrics")
    #### Build Linear SVC Model ####   
    LinearSVC(EBARecords['ROW'], EBARecords['TABLE'],"linearSVCMetrics", "linearSVCCVMetrics")    

def buildLazy():
    logging.warning("------------ Bulding Default EBA Regulatory report Modeler --------------")
    
    ###       Get Configurations
    cfg = RegUtils.getConfigs()
    
    corpusCorepPickleFile  = cfg['dir'] + cfg['corepCorpusPkl']
    recordsCorepPickleFile = cfg['dir'] + cfg['corepRecordPkl']
    corepExcelFile = cfg['dir'] + cfg['EBA_COREP']

    corpusFinrepPickleFile  = cfg['dir'] + cfg['finrepCorpusPkl']
    recordsFinrepPickleFile = cfg['dir'] + cfg['finrepRecordPkl']
    finrepExcelFile = cfg['dir'] + cfg['EBA_FINREP']
    
    ####      Parser defualt EBA FINREP and COREP Templates and convert to Pickle files
    (EBAFinrepCorpusPickel, EBAFinrepRecordsPickel ) = RegParser.excelToPickel(corpusFinrepPickleFile,
                                                                              recordsFinrepPickleFile,
                                                                              finrepExcelFile) 

    ####      Parser defualt EBA FINREP and COREP Templates and convert to Pickle files
    (EBACorepCorpusPickel, EBACorepRecordsPickel ) = RegParser.excelToPickel(corpusCorepPickleFile,
                                                                             recordsCorepPickleFile,
                                                                             corepExcelFile)
    
    ###        Build Corpus Model
    EBAFinrepCorpus = RegUtils.readPickle( EBAFinrepCorpusPickel)
    EBACorepCorpus  = RegUtils.readPickle( EBACorepCorpusPickel)    
    EBACorpus       = pd.concat([EBAFinrepCorpus,EBACorepCorpus], ignore_index = True)
    buildEBATableModels(EBACorpus, cfg)
    print ("---", cfg['EBACorpusPkl'])
    EBACorpus.to_pickle(cfg['dir'] + cfg['EBACorpusPkl'])

    ###        Build Records Model
    EBAFinrepRecords = RegUtils.readPickle(EBAFinrepRecordsPickel)
    EBACorepRecords  = RegUtils.readPickle(EBACorepRecordsPickel)
    EBARecords       = pd.concat([EBAFinrepRecords,EBACorepRecords], ignore_index = True)
    buildEBAMetricModel(EBARecords, cfg)
    EBARecords.to_pickle(cfg['dir'] + cfg['EBARecordPkl'])

    return

def buildQuick():

    logging.warning("------------ Bulding Default EBA Regulatory report Modeler --------------")
    
    corpusCorepPickleFile  = cfg['dir'] + cfg['corepCorpusPkl']
    recordsCorepPickleFile = cfg['dir'] + cfg['corepRecordPkl']
    corepExcelFile = cfg['dir'] + cfg['EBA_COREP']

    corpusFinrepPickleFile  = cfg['dir'] + cfg['finrepCorpusPkl']
    recordsFinrepPickleFile = cfg['dir'] + cfg['finrepRecordPkl']
    finrepExcelFile = cfg['dir'] + cfg['EBA_FINREP']

    EBAFinrepCorpus = RegUtils.readPickle( cfg['dir'] + cfg['finrepCorpusPkl'])    
    EBACorepCorpus  = RegUtils.readPickle( cfg['dir'] + cfg['corepCorpusPkl'])
    EBACorpus       = pd.concat([EBAFinrepCorpus,EBACorepCorpus], ignore_index = True)
    buildEBATableModels(EBACorpus, cfg)
    print ("---", cfg['EBACorpusPkl'])
    EBACorpus.to_pickle(cfg['dir'] + cfg['EBACorpusPkl'])

    ###       Buid the Models based on Metrics or Rows of each table
    EBAFinrepRecords = RegUtils.readPickle( cfg['dir'] + cfg['finrepRecordPkl'])
    EBACorepRecords  = RegUtils.readPickle( cfg['dir'] + cfg['corepRecordPkl'])
    EBARecords       = pd.concat([EBAFinrepRecords,EBACorepRecords], ignore_index = True)
    buildEBAMetricModel(EBARecords, cfg)
    EBARecords.to_pickle(cfg['dir'] + cfg['EBARecordPkl'])

    return    

if __name__ == '__main__':
    
    ###       Get Configurations
    cfg = RegUtils.getConfigs()

    buildLazy()
    #buildQuick()

    exit(0)