import RegUtils
import RegParser
import RegModels
import pandas as pd
import re
import numpy as np
from io import StringIO
import logging
logging.basicConfig(format='[%(asctime)s] %(message)s', datefmt='%m/%d/%Y %I:%M:%S %p')

## features
from sklearn.feature_extraction.text import CountVectorizer,TfidfTransformer,TfidfVectorizer
from sklearn.feature_selection import chi2
from sklearn.model_selection import train_test_split, cross_val_score





if __name__ == '__main__':
    
    logging.warning("Starting...")
    cfg = RegUtils.getConfigs()

    #(corpusPickel, corpusRecordsPicke) = RegParser.corepToPickle(cfg)

    corepCorpus = RegUtils.readPickle( cfg['dir'] + cfg['corepCorpusPkl'])

    # Create Category_id - unique id for each table
    corepCorpus['CATEGORY_ID'] =  corepCorpus['TABLE'].factorize()[0] 

    
    logging.warning("Preparing the td-idf model..")
    tfidf = TfidfVectorizer(sublinear_tf=True, min_df=2, norm='l2', encoding='latin-1', ngram_range=(1, 2), stop_words='english')
    features = tfidf.fit_transform(corepCorpus.CORPUS).toarray()
    labels = corepCorpus.CATEGORY_ID
    (x,y) = features.shape

    logging.warning("td-idf - feature shape  -    Terms = %f ", x)
    logging.warning("td-idf - feature shape  - Features = %f ", y)
    
    (x,y, MultinomialNB_model, count_vect) = RegModels.naiveBayesModel(corepCorpus['CORPUS'], corepCorpus['TABLE'])
    RegModels.saveModel(MultinomialNB_model, "multinomialNB", cfg)
    RegModels.saveModel(count_vect, "multinomialNBCV", cfg)


    (linearSCV_model, count_vect) = RegModels.linearSVCModel(corepCorpus)
    RegModels.saveModel(linearSCV_model, "linearSVC", cfg)
    RegModels.saveModel(count_vect, "linearSVCCV", cfg)
 
    logging.warning ("-------- MODEL : MultinomialNB -----------")

    message = 'OpR Advanced measurement approaches (AMA)'
    RegModels.predictMetrics(message, "multinomialNB", "multinomialNBCV" )


    #-------------------------------------
    """
    logging.warning ("-------- MODEL : Linear SVC -----------")
    
    for message in messages:
        logging.warning("%10s : %s", "Message", message)
        predict = linearSCV_model.predict(count_vect.transform([message]))
        logging.warning("%20s : %s","Prediction", predict)
    #-------------------------------------
    """