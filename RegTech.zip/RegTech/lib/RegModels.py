import nltk
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer
from difflib import SequenceMatcher

import pandas as pd
import re
import numpy as np
import pickle
import RegUtils

from io import StringIO
import logging
logging.basicConfig(format='[%(asctime)s] %(message)s', datefmt='%m/%d/%Y %I:%M:%S %p')

## features
from sklearn.feature_extraction.text import CountVectorizer,TfidfTransformer,TfidfVectorizer
from sklearn.feature_selection import chi2
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.metrics.pairwise import cosine_similarity

## load models
from sklearn.naive_bayes import MultinomialNB
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import LinearSVC

"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
    Function    : Trains and returns a model Naive Bayes model
    Model type  : Multinomial model
    Input       : x, y 
                    x : The training String 
                    y : The output
    
"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
def naiveBayesModel(x, y):
    X_train, X_test, y_train, y_test = train_test_split(x, y, random_state = 0)
    count_vect = CountVectorizer()
    X_train_counts = count_vect.fit_transform(X_train)
    tfidf_transformer = TfidfTransformer()
    X_train_tfidf = tfidf_transformer.fit_transform(X_train_counts)
    clf = MultinomialNB().fit(X_train_tfidf, y_train)
    return (X_train_tfidf,y_train, clf, count_vect)

"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
    Function    : Trains and returns a model Linear Regression model
    Model type  : Linear Regression model
    Input       : x, y 
                    x : The training String 
                    y : The output
    
"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
def linearSVCModel(x,y):
    X_train, X_test, y_train, y_test = train_test_split(x, y, random_state = 0)
    count_vect = CountVectorizer()
    X_train_counts = count_vect.fit_transform(X_train)
    tfidf_transformer = TfidfTransformer()
    X_train_tfidf = tfidf_transformer.fit_transform(X_train_counts)
    clf = LinearSVC().fit(X_train_tfidf, y_train)
    return (clf, count_vect)

"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
    Function    : Saves a Model into a given pickel file
    Input       : Model object, Model Name, Configuration  

"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
def saveModel(model, modelName,  cfg ):
    filename = cfg['dir'] + cfg[modelName]
    logging.warning("Saving the model %s to file %s", modelName, filename)
    pickle.dump(model,open(filename, 'wb'))
    return 1

"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
    Function    : Given particular confuguration and a Model name 
                  the function returns the pickel file of the model
"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
def loadModel( modelName, cfg):
    filename = cfg['dir'] + cfg[modelName]
    return pickle.load(open(filename, 'rb'))

"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
    Function    : Given a particular message or string, and a model name 
                  the function predicts the Regulatory table to which the 
                  corpus of metadata belongs to 
"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
def predictMetrics (message, modelName, modelCVName, logMessage):
    cfg =    RegUtils.getConfigs()
    mnbModel = loadModel(modelName, cfg)
    mnbModel_CV = loadModel( modelCVName, cfg)
    message_vector = mnbModel_CV.transform([message])
    prediction = mnbModel.predict(message_vector)
    return prediction

"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
    Function    : Given a particular Regulatory excel file,
                  the function parses the file (or each tab in file) and extracts the infromation.
                  Once extracted it predicts to whcih Regulagory table,
                  does the content of each tab belongs to. 
                  (It is expcted that the each tab has only table of regulatory infromation)
                  
    Return      : Returns the predicted value based on the count
"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
def predictTable(reportDf):
        toPredict=[]
        EbaTableRows=[]
        
        cfg = RegUtils.getConfigs()
        EBA_Df = RegUtils.readPickle( cfg['dir'] + cfg['EBARecordPkl'])
        EBA_Corpus_Df = RegUtils.readPickle( cfg['dir'] + cfg['EBACorpusPkl'])
        dict=[]

        # Loop thorough the rows
        #for  index , row in reportDf: 
        for  row in reportDf:
            
            colCount=0
            
            # Loop thorough columns
            for col in row:
                metric=""
                if ( re.findall( 'nan', str(col).lower())):
                    continue
                            
                if (re.findall('^\d\d\d+$', str(col))):
                    continue
                
                dataMetrics = re.search(r"[\d]+\s(.*?)$",str(col))
                if (dataMetrics):
                    dataMetrics = dataMetrics.group(1)
                else :
                    dataMetrics = str(col)
                
                # Remove digits from the strings
                if not(re.match('^[0-9\.]*$',dataMetrics) or re.match('^[0-9]*$',dataMetrics)):
                    metric = dataMetrics
                
                metric = RegUtils.cleanStrings(metric)
                # check if the ROWS are present in rows of the origianl metric
                values = EBA_Df.loc[EBA_Df['MODEL_ROW'] == metric].drop_duplicates('TABLE')['TABLE'].values
                for table in values:
                    if table:
                        EbaTableRows.append (table)
                if (metric):
                    toPredict.append (metric)
        
        if (len(toPredict) <=4):
            dict.append (["None", 0,   0])
            return pd.DataFrame(dict, columns = ['PredectionType','PredictedTable','CosinePercentage'])

        
        toPredictCorpus = " ".join(toPredict)        
        toPredictCorpus = re.sub(" \d+"," ",toPredictCorpus )       
        toPredictDf = RegUtils.getDataFrame({"CORPUS" : [toPredictCorpus]})
       
        # Type 1 - Prediction
        NaiveBayesPrediction = predictMetrics(toPredictCorpus,"multinomialNB", "multinomialNBCV", 1 )
        similarityNb = getCosineSimilarities(EBA_Corpus_Df, NaiveBayesPrediction[0], toPredictDf )
        dict.append (["multinomialNB", NaiveBayesPrediction[0],   similarityNb*100] )
        
        
        # Type 2 - Prediction
        LinearSVCPrediction = predictMetrics(toPredictCorpus, "linearSVC", "linearSVCCV" ,1)     
        similarityLSVC = getCosineSimilarities(EBA_Corpus_Df, LinearSVCPrediction[0], toPredictDf )
        dict.append (["linearSVC", LinearSVCPrediction[0],   similarityLSVC*100] )
        
        """
        if ( int(similarityNb) < 60 and int(similarityLSVC) < 60):
            # Type 3 - Prediction 
            # Not really a prediction but checks the matching records from record database
            for table in EbaTableRows:
                if (table):               
                    similarity = getCosineSimilarities(EBA_Corpus_Df, table,toPredictDf )
                    dict.append (["RecordsTable", table,   similarity*100] )
        """    
        return pd.DataFrame(dict, columns = ['PredectionType','PredictedTable','CosinePercentage'])

"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
    Function    : getCosineSimilarities

    Description : The function checks two different vectors and returns the similarity between the 
                  the two vectors. Here, we pass the vector, whose value needs to be predicted
                  and we also pass the corpus which we think that have already found.

    Return      : Returs a number cosine value between 0 and 1.
                  if value returned is close to 0 : then the vectors are dis-similarity
                  if value returned is close to 1 : then the vectors display high similarity
"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
def getCosineSimilarities(df, table, toPredictDf ):
        corpus = RegUtils.getMetricValueFromEBA(df,"TABLE","CORPUS",table)
        corpusDf = RegUtils.getDataFrame({"CORPUS" : [corpus], "TABLE" : table })
        vectorizer  = TfidfVectorizer(min_df=1,ngram_range=(1, 2), stop_words = 'english')
        tfIdf = vectorizer.fit_transform(corpusDf.CORPUS).toarray()
        toPredictTfIdf = vectorizer.transform(toPredictDf.CORPUS).toarray()
        return cosine_similarity(tfIdf, toPredictTfIdf )[0][0]