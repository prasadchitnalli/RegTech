import nltk
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer

import pandas as pd
import re
import numpy as np
import pickle
import RegUtils


from io import StringIO
import logging
logging.basicConfig(format='[%(asctime)s] %(message)s', datefmt='%m/%d/%Y %I:%M:%S %p')

## features
from sklearn.feature_extraction.text import CountVectorizer,TfidfTransformer,TfidfVectorizer
from sklearn.feature_selection import chi2
from sklearn.model_selection import train_test_split, cross_val_score

## load models
from sklearn.naive_bayes import MultinomialNB
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import LinearSVC

def naiveBayesModel(x, y ):

    #X_train, X_test, y_train, y_test = train_test_split(corpusDf['CORPUS'], corpusDf['TABLE'], random_state = 0)
    X_train, X_test, y_train, y_test = train_test_split(x, y, random_state = 0)

    count_vect = CountVectorizer()
    X_train_counts = count_vect.fit_transform(X_train)
    tfidf_transformer = TfidfTransformer()
    X_train_tfidf = tfidf_transformer.fit_transform(X_train_counts)
    clf = MultinomialNB().fit(X_train_tfidf, y_train)

    return (X_train_tfidf,y_train, clf, count_vect)

def linearSVCModel(corpusDf):

    X_train, X_test, y_train, y_test = train_test_split(corpusDf['CORPUS'], corpusDf['TABLE'], random_state = 0)

    count_vect = CountVectorizer()
    X_train_counts = count_vect.fit_transform(X_train)
    tfidf_transformer = TfidfTransformer()
    X_train_tfidf = tfidf_transformer.fit_transform(X_train_counts)
    clf = LinearSVC().fit(X_train_tfidf, y_train)

    return (clf, count_vect)

def saveModel(model, modelName,  cfg ):
    filename = cfg['dir'] + cfg[modelName]
    logging.warning("Saving the model %s to file %s", modelName, filename)
    pickle.dump(model,open(filename, 'wb'))
    return 1

def loadModel( modelName, cfg):
    filename = cfg['dir'] + cfg[modelName]
    return pickle.load(open(filename, 'rb'))

def predictMetrics (message, modelName, modelCVName):

    cfg =    RegUtils.getConfigs()
    mnbModel = loadModel(modelName, cfg)
    mnbModel_CV = loadModel( modelCVName, cfg)

    logging.warning("%10s : %s", "Message", message)
    message_vector = mnbModel_CV.transform([message])
    predict = mnbModel.predict(message_vector)
    logging.warning("%20s : %s","Prediction", predict)
