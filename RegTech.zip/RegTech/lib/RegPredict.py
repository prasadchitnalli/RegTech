import sys
from optparse import OptionParser
import RegModels
import RegUtils
import RegParser
import re
import logging
logging.basicConfig(format='[%(asctime)s] %(message)s', datefmt='%m/%d/%Y %I:%M:%S %p')



if __name__ == "__main__":

    parser = OptionParser()
    (options, args) = parser.parse_args()

    fileName = ' '.join(args)
    predictedTable = RegParser.readExcel(fileName)
    exit (0)
