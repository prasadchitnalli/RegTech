import sys
from optparse import OptionParser
import RegModels

if __name__ == "__main__":

    parser = OptionParser()
    (options, args) = parser.parse_args()
    message = ' '.join(args)
    

    RegModels.predictMetrics(message,"multinomialNB", "multinomialNBCV" )
