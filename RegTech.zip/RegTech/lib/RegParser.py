import pandas as pd
import re
import numpy as np
import RegUtils

from io import StringIO
import logging
logging.basicConfig(format='[%(asctime)s] %(message)s', datefmt='%m/%d/%Y %I:%M:%S %p')

def corepToPickle (cfg):

    corpusPickleFile  = cfg['dir'] + cfg['corepCorpusPkl']
    recordsPickleFile = cfg['dir'] + cfg['corepRecordPkl']
    excelFile = cfg['dir'] + cfg['EBA_COREP']

    (corepReports, corepRecords) = RegUtils.parseRegExcelReport(excelFile)

    corepCorpus  = pd.DataFrame(corepReports)
    corepRecords = pd.DataFrame(corepRecords)

    logging.warning("Writing the corpus to  pickle file  %s", corpusPickleFile)
    corepCorpus.to_pickle(corpusPickleFile)

    logging.warning("Writing the Table records to  pickle file  %s", recordsPickleFile)
    corepRecords.to_pickle(recordsPickleFile)

    return (corpusPickleFile, recordsPickleFile)