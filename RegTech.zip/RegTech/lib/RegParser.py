import pandas as pd
import re
import numpy as npE
import RegUtils
import RegModels
from io import StringIO
import logging
logging.basicConfig(format='[%(asctime)s] %(message)s', datefmt='%m/%d/%Y %I:%M:%S %p')

""" 

"""
def excelToPickel (corpusPickleFile,recordsPickleFile,excelFile):
    (reportDetails, records) = parseExcel(excelFile)
    corpus  = pd.DataFrame(reportDetails)
    records = pd.DataFrame(records)
    logging.warning("Writing the corpus to  pickle file  %s", corpusPickleFile)
    corpus.to_pickle(corpusPickleFile)
    logging.warning("Writing the Table records to  pickle file  %s", recordsPickleFile)
    records.to_pickle(recordsPickleFile)
    return (corpusPickleFile, recordsPickleFile)


def parseExcel (fileName):
    
    corpusDict= []
    corepFullCorpusDict=[]
    logging.warning('Reading file  %s', (fileName))
    excel = pd.ExcelFile(fileName, header=None, sheet_name = 'None')    
    count = 0
    table={"0" : "0"}
    print ('  %-20s  %-20s ' % ( "TRAINING_STATUS", "TABE_NAME"))
    print ('  %-20s  %-20s ' % ( "---------------", "-----------"))
    # Iterate through each sheet in excel
    for sheets in excel.sheet_names:      
        listOfStrings =[]
        count += 1
        rowCount = 0
        report = pd.read_excel(fileName , sheet_name=sheets)
        if sheets == 'TOC':
            continue
       
        table_name = list(report.columns.values)[0]
        tableIdentifier = re.search(r"^(.*?\.\d\d).*$", sheets)
        
        
        # we dont want to memorize what we have aready done with!
        if (tableIdentifier.group(1) in table ):
            print ('  %-20s  %-20s ' % ( "SKIP", table_name))
            continue
        else :
            table.update( { tableIdentifier.group(1)  : "1"} )
        
        print ('  %-20s  %-20s ' % ( "PARSING", table_name))        

        # Iterate through each row
        for  index , row in report.iterrows():
            colNum = 0
            rowCount += 1
            metrics = ""
            categories=""
            category_id=""
            category_desc=""
            rowId = ""

            #if (rowCount==1):
            #    listOfStrings.append(table_name)

            # Iterate through each columns
            for col in row :
                colNum+=1
                # Remove - Nulls or nan in Pandas
                if ( re.findall( 'nan', str(col).lower())):
                    continue
                
                # We see the data starts to be presented in the Column number 2 for each excel tab
                if (colNum == 2):

                    # Pick only the rows
                    if (re.search(r"\((.+?)\:(.+?)\)\s(.*?)$", str(col)) or str(col).lower()=='metric'):
                        #print (str(col))
                        continue

                    metrics = RegUtils.cleanStrings(str(col))
                    metrics_orignal = (str(col))
                    
                    listOfStrings.append(metrics)
                elif (colNum == 3):
                    rowId = str(col)
                else :
                    # Get information from each cell of a row
                    if (colNum != 2):
                        AccountingMetrics = re.search(r"\((.+?)\)\s(.*?)\[(.*?)\]$", str(col))
                        # (mi76) Computable amount [mi]
                        if (AccountingMetrics):
                            categories = AccountingMetrics.group(1)
                            category_desc = AccountingMetrics.group(2)

                        BaseMetrics  = re.search(r"\((.+?)\:(.+?)\)\s(.*?)$", str(col))
                        if (BaseMetrics):
                            column = colNum
                            categories=BaseMetrics.group(1)
                            category_id=BaseMetrics.group(2)
                            category_desc=BaseMetrics.group(3)
                        
                        if (metrics):
                            corpusDict.append({ "TABLE" : sheets ,
                                                     "TABLE_LABEL" : table_name ,
                                                     "MODEL_ROW" : metrics,
                                                     "ROW" : metrics_orignal,
                                                     "ROW_ID" : rowId,
                                                     "MEMBER" : categories,
                                                     "MEMBER_ID" : category_id,
                                                     "MEMBER_DESC" : category_desc
                                                    })
                                                
        #print (listOfStrings)
        metricCorpus = " ".join(listOfStrings)
        corepFullCorpusDict.append({ "TABLE" : sheets , 'CORPUS' : metricCorpus})

        #if count == 11 :
        #    break
    return (corepFullCorpusDict , corpusDict)


def extractTables(report):
    table=[]
    rowList=[]
    for (index,row) in report.iterrows():            
        if (RegUtils.isEmptyRow(row)):
            table.append(rowList)
            rowList=[]
        else:
            row = row.values.tolist()
            rowList.append(row)

    table.append(rowList)
    return table


def readExcel(ExcelFile):
    tableCorpus = []
    logging.warning('Reading file %s', (ExcelFile))
    excel = pd.ExcelFile(ExcelFile, header=None, sheet_name = 'None')

    for sheets in excel.sheet_names:
        sheetData = pd.read_excel(ExcelFile , sheet_name=sheets)
        # extract table infromation
        tableCorpus = extractTables(sheetData)

        for table in tableCorpus:
            if (table):

                predictedDf = RegModels.predictTable(table)
                """
                print ("------------------------------------------------------------")
                print ('PredictedValues : ')
                print (predictedDf)
                print ("------------------------------------------------------------")
                """
                maxValue = predictedDf.loc[predictedDf['CosinePercentage'].idxmax()]
                #print (maxValue.PredectionType, maxValue.PredictedTable, maxValue.CosinePercentage)
                if (float(maxValue.CosinePercentage) > 65) :
                    logging.warning("Sheet : %-20s [ %15s : %-20s %10s : %-10s %s : %-10s ]" % (sheets,
                                                                                    "Predicted Table",maxValue.PredictedTable,
                                                                                    "Corelation",int(maxValue.CosinePercentage),
                                                                                    "Type",maxValue.PredectionType))

                
    
    return 
