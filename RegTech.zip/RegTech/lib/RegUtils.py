import pandas as pd
import re
import numpy as np
import os
import json
from io import StringIO
import logging
logging.basicConfig(format='[%(asctime)s] %(message)s', datefmt='%m/%d/%Y %I:%M:%S %p')


def getConfigs():
    cwd = os.getcwd()
    configFile = cwd + "/config/param.json"
    with open(configFile) as fileJson:    
        params = json.load(fileJson)
    params.update({"dir" : cwd})
    return params

def readPickle(pklFile):
    return pd.read_pickle( pklFile)

def cleanStrings(str):
    str=str.lower()
    str=str.rstrip()
    str=re.sub('[^A-Za-z0-9 ]+', '', str)    
    return str

def getDataFrame (dictOfData):
    return pd.DataFrame (dictOfData)

def getMetricValueFromEBA(df,col1, col2, value):
    return "".join(df.loc[df[col1] == value].drop_duplicates(col2)[col2].values)

def isEmptyRow(rowDf):
    returnValue=0
    list=[]
    for element in rowDf:
        if(str(element)=='nan'):
            list.append("")
        else:
            list.append(str(element))

    if ("".join(list)==''):
        returnValue=1
    
    return returnValue
