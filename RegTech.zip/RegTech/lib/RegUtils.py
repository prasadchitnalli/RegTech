import pandas as pd
import re
import numpy as np
import os
import json
from io import StringIO


import logging
logging.basicConfig(format='[%(asctime)s] %(message)s', datefmt='%m/%d/%Y %I:%M:%S %p')

def parseRegReport (fileName):
    
    corepCorpusDict= []
    
    #print ("Reading file - %s"  % (fileName))
    logging.warning('Reading file - %s', (fileName))
    excel = pd.ExcelFile(fileName, header=None, sheet_name = 'None')    

    count = 0
    for sheets in excel.sheet_names:
        listOfStrings =[]
        count += 1
        report = pd.read_excel(fileName , sheet_name=sheets)

        if sheets == 'TOC':
            continue
        #print ("Sheet - %s"  % (sheets))
        logging.warning('Sheet - %s', (sheets))
        for  index , row in report.iterrows():
            colNum = 0
            categories = []
            cellMetrics = []
            #print (row)
            for col in row :            
                colNum+=1
                # Remove - Nulls or nan in Pandas
                if ( re.findall( 'nan', str(col).lower())):
                    continue

                if (colNum == 2):
                    categories = str(col)
                    listOfStrings.append(str(col))

        metricCorpus = " ".join(listOfStrings)
        corepCorpusDict.append({ "TABLE" : sheets , 'CORPUS' : metricCorpus})

        if count == 5 :
            break
    return corepCorpusDict

#----------------------------------------#
def parseRegExcelReport (fileName):
    
    corepCorpusDict= []
    corepFullCorpusDict=[]

    logging.warning('Reading file ---- %s', (fileName))
    excel = pd.ExcelFile(fileName, header=None, sheet_name = 'None')    

    count = 0
    for sheets in excel.sheet_names:
        listOfStrings =[]
        count += 1
        report = pd.read_excel(fileName , sheet_name=sheets)

        if sheets == 'TOC':
            continue

        logging.warning('Sheet - %s', (sheets))
        for  index , row in report.iterrows():
            colNum = 0
            metrics = ""
            categories=""
            category_id=""
            category_desc=""
            AccCode=""
            AccDesc=""
            rowId = ""
            
            for col in row :            
                colNum+=1
        
                # Remove - Nulls or nan in Pandas
                if ( re.findall( 'nan', str(col).lower())):
                    continue

                if (colNum == 2):
                    metrics = str(col)
                    listOfStrings.append(str(col))
                elif (colNum == 3):
                    rowId = str(col)
                else :
                    
                    AccountingMetrics = re.search(r"\((.+?)\)\s(.*?)\[(.*?)\]$", str(col))
                    if (AccountingMetrics):
                        AccCode = AccountingMetrics.group(0)
                        AccDesc = AccountingMetrics.group(1)

                    BaseMetrics  = re.search(r"\((.+?)\:(.+?)\)\s(.*?)$", str(col))
                    if (BaseMetrics):
                        column = colNum
                        categories=BaseMetrics.group(1)
                        category_id=BaseMetrics.group(2)
                        category_desc=BaseMetrics.group(3)
                    
                    #print ( metrics,"---", categories, "---",category_id, "---",category_desc , AccCode, AccDesc)    
                
                    if (metrics):
                        corepCorpusDict.append({ "TABLE" : sheets ,
                                                 "ROW" : metrics,
                                                 "ROW_ID" : rowId,
                                                 "METRIC_CODE" : AccCode,
                                                 "METRIC_DESC" : AccDesc,
                                                 "METRIC_CATEGORY" : categories,
                                                 "METRIC_CAT_ID" : category_id,
                                                 "METRIC_CAT_DESC" : category_desc,
                                                 
                                                })


        metricCorpus = " ".join(listOfStrings)
        corepFullCorpusDict.append({ "TABLE" : sheets , 'CORPUS' : metricCorpus})

        if count == 5 :
            break
    return (corepFullCorpusDict , corepCorpusDict)


def getConfigs():
    cwd = os.getcwd()

    configFile = cwd + "/config/param.json"

    
    with open(configFile) as fileJson:    
        params = json.load(fileJson)

    logging.warning("Preparing configs")
    params.update({"dir" : cwd})
    for k, v in params.items():
        logging.warning("%20s : %s", k, v)
    return params
    
def readPickle(pklFile):
    return pd.read_pickle( pklFile)

