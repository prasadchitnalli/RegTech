clear 

python lib/RegPredict.py $1
