clear
python lib/RegMet.py